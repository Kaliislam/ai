"""TurkishJARVIS UI modülleri."""
