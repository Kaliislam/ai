"""TurkishJARVIS API router package."""
