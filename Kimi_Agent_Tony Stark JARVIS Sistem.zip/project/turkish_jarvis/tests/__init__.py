"""TurkishJARVIS test package."""
