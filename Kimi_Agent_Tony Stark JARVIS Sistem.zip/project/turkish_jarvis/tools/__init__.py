"""TurkishJARVIS tools modülleri."""
