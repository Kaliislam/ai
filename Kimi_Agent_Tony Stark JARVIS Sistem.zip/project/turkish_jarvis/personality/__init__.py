"""TurkishJARVIS personality modülleri."""
