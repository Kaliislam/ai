"""TurkishJARVIS memory modülleri."""
