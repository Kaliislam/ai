"""TurkishJARVIS utils modülleri."""
